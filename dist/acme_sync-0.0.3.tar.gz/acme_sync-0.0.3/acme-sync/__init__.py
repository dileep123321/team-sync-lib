def ping():
    return "pong from GAR via OIDC CI/CD!"
