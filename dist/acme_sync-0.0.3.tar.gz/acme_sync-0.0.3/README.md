Simple Python library for testing Google Artifact Registry CI/CD with OIDC.
